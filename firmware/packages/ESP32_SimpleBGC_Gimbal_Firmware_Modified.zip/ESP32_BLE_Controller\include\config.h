#pragma once

/*
 * ESP32 #1 — HANDHELD CONTROLLER / BLE TRANSMITTER
 *
 * Reads three analog joystick channels, applies center / dead-zone / optional
 * light filtering, and writes ASCII "x,y,z" packets to the gimbal ESP32.
 *
 * Companion firmware: ESP32_BaseCam_Gimbal (BLE server).
 * Keep BLE_SERVICE_UUID, BLE_CHAR_UUID and the packet format in sync with that
 * project. The original firmware used the same UUIDs and CSV payload.
 *
 * Logical axis mapping (unchanged from the original sketch):
 *   X  ->  Pitch
 *   Y  ->  Yaw
 *   Z  ->  Roll
 */

/* ---- Joystick GPIO ------------------------------------------------------- */
/* Original sketch: GPIO 4 / 5 / 6. Target wiring: GPIO 6 / 7 / 15. */
#define JOY_X_PIN                       6
#define JOY_Y_PIN                       7
#define JOY_Z_PIN                       15

/* GPIO15 is ADC2 on ESP32-S3. BLE uses the radio; ADC2 can be noisier than
 * ADC1 (GPIO 1–10). If Z-axis readings are unstable, move Z to an ADC1 pin
 * and update this define (and the gimbal Direct-mode pin) together. */

#define ADC_RESOLUTION_BITS             12
#define ADC_MAX_VALUE                   4095
#define JOYSTICK_CENTER_SAMPLES         16
#define JOYSTICK_DEADZONE               30          /* raw ADC counts after centering */

/* Light EMA. 0 = off. 2 ≈ 4-sample equivalent, low latency.
 * Original client had no filter. */
#define JOYSTICK_FILTER_SHIFT           2

/* ---- BLE (must match ESP32_BaseCam_Gimbal) -------------------------------- */
#define BLE_TARGET_DEVICE_NAME          "ESP32_S3_BLE"
#define BLE_SERVICE_UUID                "4fafc201-1fb5-459e-8fcc-c5c9c331914b"
#define BLE_CHAR_UUID                   "beb5483e-36e1-4688-b7f5-ea07361b26a8"

#define BLE_SEND_INTERVAL_MS            20          /* same cadence as CMD_CONTROL_DELAY */
#define BLE_SCAN_TIME_SECONDS           3
#define BLE_RECONNECT_DELAY_MS          1000
#define BLE_PACKET_MAX_LEN              32

/* ---- Debug UART (USB CDC on ESP32-S3) ------------------------------------ */
#define DEBUG_SERIAL_BAUD               115200
#define SERIAL_WAIT_TIMEOUT_MS          2000
#define SERIAL_DEBUG_ENABLED            1
